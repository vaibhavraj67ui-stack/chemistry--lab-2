const notes = [
 {chapter:"विलयन (Solutions)", tags:"molarity molality raoult colligative", points:["विलयन = solute + solvent का समांगी मिश्रण।","Molarity (M) = solute के moles / solution का volume (L)।","Molality (m) = solute के moles / solvent का mass (kg)।","Raoult का नियम: p = x p°; ideal solution में intermolecular interactions लगभग समान होते हैं।","Colligative properties कणों की संख्या पर निर्भर करती हैं, nature पर नहीं।"]},
 {chapter:"वैद्युत रसायन (Electrochemistry)", tags:"galvanic cell nernst conductivity", points:["Oxidation anode पर और reduction cathode पर होती है।","E°cell = E°cathode − E°anode।","ΔG° = −nFE°cell; spontaneous cell के लिए E°cell positive होता है।","Salt bridge electrical neutrality बनाए रखने में मदद करता है।"]},
 {chapter:"रासायनिक बलगतिकी (Chemical Kinetics)", tags:"rate order first order half life", points:["Reaction rate = concentration में परिवर्तन / समय।","Rate law प्रयोग से पता चलता है; इसे हमेशा balanced equation से नहीं निकाला जा सकता।","First-order reaction का half-life: t½ = 0.693/k।","Rate constant k की unit reaction order पर निर्भर करती है।"]},
 {chapter:"d- और f-ब्लॉक तत्व", tags:"transition lanthanoid actinoid", points:["Transition elements में atom या common ion के d-subshell में partially filled orbitals होते हैं।","Variable oxidation states का कारण ns और (n−1)d orbitals की energy का करीब होना है।","Lanthanoid contraction का कारण 4f electrons की कमजोर shielding है।"]},
 {chapter:"समन्वय यौगिक (Coordination Compounds)", tags:"ligand coordination number isomerism", points:["Central metal atom/ion से जुड़े ions या molecules ligands कहलाते हैं।","Coordination number = central metal से directly जुड़े donor atoms की संख्या।","Ligands monodentate या polydentate हो सकते हैं।","Isomerism में समान molecular formula के बावजूद arrangement अलग होता है।"]},
 {chapter:"हैलोऐल्केन एवं हैलोऐरीन", tags:"sn1 sn2 haloalkane", points:["C–X bond polar होता है; X halogen है।","SN1 reaction दो मुख्य steps में और carbocation intermediate के साथ होती है।","SN2 reaction एक step में backside attack से होती है।","Aryl halides में C–X bond resonance के कारण अपेक्षाकृत मजबूत होता है।"]},
 {chapter:"ऐल्कोहॉल, फीनॉल एवं ईथर", tags:"alcohol phenol ether williamson", points:["Alcohol में –OH group saturated carbon से जुड़ा होता है।","Phenol alcohol से अधिक acidic होता है क्योंकि phenoxide ion resonance से स्थिर होता है।","Williamson synthesis: sodium alkoxide + primary alkyl halide → ether।"]},
 {chapter:"ऐल्डिहाइड, कीटोन एवं कार्बोक्सिलिक अम्ल", tags:"aldehyde ketone aldol cannizzaro", points:["Aldehyde में –CHO और ketone में >C=O group होता है।","Aldol reaction के लिए सामान्यतः α-hydrogen आवश्यक है।","Cannizzaro reaction ऐसे aldehyde में होती है जिसमें α-hydrogen नहीं होता।","Carboxylic acids में –COOH functional group होता है।"]},
 {chapter:"ऐमीन (Amines)", tags:"amine basicity diazonium hoffmann", points:["Amines ammonia के derivatives हैं।","Aromatic primary amine diazotisation से diazonium salt दे सकता है।","Hoffmann bromamide reaction में amide से एक carbon कम वाला primary amine बनता है।"]},
 {chapter:"जैव-अणु (Biomolecules)", tags:"carbohydrate protein dna vitamin", points:["Glucose एक aldohexose है।","Proteins amino acids के polymers हैं जो peptide bonds से जुड़े होते हैं।","DNA में genetic information store होती है; RNA protein synthesis में महत्वपूर्ण है।","Vitamins शरीर को कम मात्रा में चाहिए; deficiency से specific disorders हो सकते हैं।"]}
];
const quiz = [
 {q:"Molarity की सही परिभाषा क्या है?",o:["Moles of solute / kg solvent","Moles of solute / litre solution","Mass of solute / litre solvent","Moles of solvent / litre solution"],a:1,e:"Molarity में solution का volume litre में लिया जाता है।"},
 {q:"Oxidation किस electrode पर होती है?",o:["Cathode","Salt bridge","Anode","दोनों पर हमेशा"],a:2,e:"याद रखो: Anode = Oxidation, Cathode = Reduction."},
 {q:"First-order reaction का half-life है:",o:["k/0.693","0.693/k","1/k²","2.303k"],a:1,e:"First-order reaction के लिए t½ = 0.693/k."},
 {q:"Phenol alcohol से अधिक acidic क्यों है?",o:["Phenol में hydrogen नहीं होता","Phenoxide ion resonance से स्थिर होता है","Alcohol में oxygen नहीं होता","Phenol हमेशा ionic होता है"],a:1,e:"Conjugate base phenoxide resonance से stabilize होता है।"},
 {q:"SN2 reaction सामान्यतः किस तरह होती है?",o:["दो steps में carbocation के साथ","एक step में backside attack","Free radical chain से","केवल aromatic ring पर"],a:1,e:"SN2 concerted, one-step mechanism है।"},
 {q:"Hoffmann bromamide reaction में product amine में carbon atoms:",o:["एक ज्यादा होते हैं","समान रहते हैं","एक कम होते हैं","दो कम होते हैं"],a:2,e:"Amide से एक carbon कम वाला primary amine बनता है।"},
 {q:"Coordination number क्या बताता है?",o:["Metal का atomic number","Directly attached donor atoms की संख्या","Ligand का charge हमेशा","Complex का total mass"],a:1,e:"Donor atoms की direct bonding count की जाती है।"},
 {q:"Raoult's law का सामान्य रूप है:",o:["p = x p°","PV = nRT²","E = mc²","π = Kf/m"],a:0,e:"Ideal solution में component का partial pressure p = x p°."},
 {q:"DNA का प्रमुख कार्य क्या है?",o:["केवल energy बनाना","Genetic information store करना","Oxygen transport करना","Fat digestion करना"],a:1,e:"DNA genetic information store करता है।"},
 {q:"Cannizzaro reaction सामान्यतः किन aldehydes में होती है?",o:["जिनमें α-hydrogen हो","जिनमें α-hydrogen न हो","सभी ketones में","सभी alcohols में"],a:1,e:"α-H न होने वाले aldehydes concentrated alkali में disproportionation कर सकते हैं।"}
];
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
function showPage(id){ $$(".page").forEach(p=>p.classList.toggle("active",p.id===id)); $$(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===id)); window.scrollTo({top:0,behavior:"smooth"}); }
$$("[data-tab]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.tab)));
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.go)));
function renderNotes(filter=""){
 const list=$("#notesList"), q=filter.trim().toLocaleLowerCase();
 const filtered=notes.filter(n=>(n.chapter+" "+n.tags+" "+n.points.join(" ")).toLocaleLowerCase().includes(q));
 if(!filtered.length){list.innerHTML='<div class="empty">Is search se koi topic nahi mila. Dusra keyword try karo.</div>';return;}
 list.innerHTML=filtered.map(n=>`<article class="note-card"><h3>${n.chapter}</h3><ul>${n.points.map(p=>`<li>${p}</li>`).join("")}</ul></article>`).join("");
}
$("#noteSearch").addEventListener("input",e=>renderNotes(e.target.value)); renderNotes();
let qi=0, answers={}, checked=false;
function renderQuiz(){
 const item=quiz[qi]; checked=false; $("#quizCount").textContent=`Question ${qi+1} / ${quiz.length}`;
 $("#quizArea").innerHTML=`<div class="question-number">QUESTION ${qi+1} OF ${quiz.length}</div><div class="question-text">${item.q}</div><div class="options">${item.o.map((o,i)=>`<label class="option ${answers[qi]===i?"selected":""}" data-option="${i}"><input type="radio" name="answer" value="${i}" ${answers[qi]===i?"checked":""}><span>${o}</span></label>`).join("")}</div>`;
 $$(".option").forEach(el=>el.addEventListener("click",()=>{if(checked)return; answers[qi]=Number(el.dataset.option); $$(".option").forEach(x=>x.classList.toggle("selected",x===el));}));
 $("#quizFeedback").textContent=""; $("#scoreBox").hidden=true; $("#checkBtn").hidden=false; $("#nextBtn").hidden=true;
}
$("#checkBtn").addEventListener("click",()=>{
 if(checked)return;
 if(answers[qi]===undefined){$("#quizFeedback").textContent="Pehle ek option select karo 🙂";return;}
 checked=true; const item=quiz[qi], picked=answers[qi], correct=picked===item.a;
 $$(".option").forEach((el,i)=>{el.classList.remove("selected");if(i===item.a)el.classList.add("correct");else if(i===picked&&!correct)el.classList.add("wrong");});
 $("#quizFeedback").textContent=(correct?"✅ Sahi jawab! ":"❌ Is baar galat. ")+item.e;
 $("#checkBtn").hidden=true;
 if(qi<quiz.length-1)$("#nextBtn").hidden=false;
 else {const score=quiz.reduce((s,q,i)=>s+(answers[i]===q.a?1:0),0);$("#scoreBox").hidden=false;$("#scoreBox").textContent=`🎉 Test complete! Score: ${score}/${quiz.length}. ${score>=8?"Bahut badhiya!":"Galat questions ke explanations dobara revise karo."}`;}
});
$("#nextBtn").addEventListener("click",()=>{if(qi<quiz.length-1){qi++;renderQuiz();}});
$("#restartBtn").addEventListener("click",()=>{qi=0;answers={};renderQuiz();});
renderQuiz();
let installPrompt;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();installPrompt=e;$("#installBtn").hidden=false;});
$("#installBtn").addEventListener("click",async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;$("#installBtn").hidden=true;});
if("serviceWorker" in navigator && location.protocol.startsWith("http")){
 window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").then(()=>{$("#connection").textContent="✅ App ready · Offline support enabled";}).catch(()=>{$("#connection").textContent="App ready · Offline cache setup nahi ho paya";}));
}
if(!navigator.onLine)$("#connection").textContent="📴 Offline mode · Saved content available";
window.addEventListener("online",()=>$("#connection").textContent="🌐 Online · App ready");
window.addEventListener("offline",()=>$("#connection").textContent="📴 Offline mode · Saved content available");
